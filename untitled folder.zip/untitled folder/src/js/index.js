const fs = require("fs");
const path = require("path");
const screenshot = require("desktop-screenshot");

// shortcut
var option = {
  key: "Ctrl+X",
  active: search,
  failed: function(msg) {
    // :(, fail to register the |key| or couldn't parse the |key|.
    console.log(msg);
  }
};
var shortcut = new nw.Shortcut(option);
nw.App.registerGlobalHotKey(shortcut);
// open a new fullscreen window
function search() {
  // get screen attribute
  var screens = nw.Screen.screens,
    bounds = screens[0].bounds;
  screenshot("shot.png", (err, complete) => {
    if (err) {
      console.log(err);
    } else {
      var imgPath = path.join(global.__dirname, "./shot.png");
      var imgBuff = fs.readFileSync(imgPath);
      var buffer = Buffer.from(imgBuff);
      var b64 = buffer.toString("base64");
      var ba64 = "data:image/jpeg;base64," + b64;
      window.localStorage.setItem("screenshot64", ba64);
      nw.Window.open("dist/screenshot.html", {
        fullscreen: true,
        frame: false
      });
    }
  });
}
