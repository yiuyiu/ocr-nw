var gulp = require("gulp"),
  sass = require("gulp-sass"),
  concat = require("gulp-concat"),
  base64 = require("gulp-base64"),
  uglify = require("gulp-uglify"),
  autopre = require("gulp-autoprefixer"),
  del = require("del"),
  zip = require("gulp-zip"),
  nwBuilder = require("nw-builder"),
  info = require("./package"),
  browserSync = require("browser-sync").create(),
  reload = browserSync.reload;
var exec = require("child_process").exec;
// 配置了sass,自动添加前缀,重命名添加min后缀,压缩css
gulp.task("css", function() {
  gulp
    .src("./src/sass/*.scss")
    // .pipe(plugins.sass())
    .pipe(sass().on("error", sass.logError))
    .pipe(autopre())
    .pipe(
      base64({
        extensions: ["svg", "png", /\.jpg#datauri$/i],
        maxImageSize: 8 * 1024 // bytes
      })
    )
    // .pipe(gulp.dest("./src/css"))
    // .pipe(plugins.rename({ suffix: '.min' }))
    // .pipe(plugins.cleanCss())
    .pipe(gulp.dest("./dist/css"))
    .pipe(reload({ stream: true }));
});
gulp.task("html", function() {
  gulp.src("./src/*.html").pipe(gulp.dest("./dist"));
});
gulp.task("js", function() {
  gulp.src("./src/js/**/*.js").pipe(gulp.dest("./dist/js"));
});
gulp.task("image", function() {
  gulp.src("./src/img/**/*").pipe(gulp.dest("./dist/img"));
});
// 静态服务器 + 监听 scss/html 文件
gulp.task("serve", ["css"], function() {
  browserSync.init({
    server: {
      baseDir: "./dist/"
    }
  });
  gulp.watch("src/img/**/*", ["image"]);
  gulp.watch("src/sass/*.scss", ["css"]);
  // gulp.watch("dist/*.html").on('change', reload);
  gulp.watch("./src/*.html").on("change", reload);
  gulp.watch("./src/*.html", ["html"]);
  gulp.watch("./src/**/*.js", ["js"]);
});
// gulp.task('build',['styles']);
// gulp.task('watch',function () {
//     gulp.watch(['sass/*.scss'],['styles']);
// })
gulp.task("default", ["serve", "image", "js"]);
// nwBuilder
var depends = Object.keys(info.dependencies).join(",");
gulp.task("build", ["css", "html", "js"], cb => {
  var nw = new nwBuilder({
    files: "./{package.json,dist/**,node_modules/{" + depends + "}/**}", // use the glob format
    platforms: ["osx64", "win32", "win64"],
    version: "0.14.7",
    flavor: "normal"
  });
  nw.on("log", console.log);
  nw.build(cb);
});
gulp.task("run", ["css", "html", "js"], cb => {
  var nw = new nwBuilder({
    files: "./{package.json,dist/**,node_modules/{" + depends + "}/**}", // use the glob format
    platforms: ["osx64"],
    version: "0.14.7"
  });
  nw.build().then(() => {
    exec("./build/ocr/osx64/ocr.app/Contents/MacOS/nwjs");
  });
});
gulp.task("release", ["build"], function() {
  return gulp
    .src(["./src/shell/*", "./build/nwMusicBox/linux64/**"])
    .pipe(zip(info.version + "linux64.zip"))
    .pipe(gulp.dest("./release/" + info.version));
});
