to do list:

1. uglify compress js
